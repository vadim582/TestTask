﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net.Http;
using System.Web;
using WpfApp2.Models;
using WpfApp2.ViewModels;
using System.Net;
using Newtonsoft.Json;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using WpfApp2.Views;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //static WebClient wc = new WebClient();
        //string json = wc.DownloadString("https://api.coincap.io/v2/assets?limit=10");
        List<Currency> currencies = new List<Currency>();
        public Currency SelectedCurrency { get; set; }
        public MainWindow()
        {
            var viewModel = new TopCurrenciesViewModel();

            DataContext = viewModel;
            string json = File.ReadAllText("ApiData.json");
            currencies = JsonConvert.DeserializeObject<List<Currency>>(json);
            InitializeComponent();
            listView.ItemsSource = currencies; 
            CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(listView.ItemsSource);
            view.Filter = Filter;
        }
        private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            var urlPart = ((Hyperlink)sender).NavigateUri;
            var fullUrl = string.Format("", urlPart);
            Process.Start(new ProcessStartInfo(fullUrl));
            e.Handled = true;
        }
        private bool Filter(object item)
        {
            if (String.IsNullOrEmpty(searchTextBox.Text))
                return true;
            else
                return ((item as Currency).Name.IndexOf(searchTextBox.Text, StringComparison.OrdinalIgnoreCase) >= 0);
        }

        private void TextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            CollectionViewSource.GetDefaultView(listView.ItemsSource).Refresh();
        }
        //private void Hyperlink_Click(object sender, RoutedEventArgs e)
        //{
        //    string dynamicLink = linkB;

        //    Process.Start(dynamicLink);
        //}
    }
    //private void GetData_Click(object sender, RoutedEventArgs e)
    //{
    //    string json = File.ReadAllText("ApiData.json");
    //    //File.WriteAllLines("ApiData.json", json, Encoding.UTF8);
    //    currencies = JsonConvert.DeserializeObject<List<Currency>>(json);
    //}
}
