﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2.Models
{
    public class Currency : INotifyPropertyChanged
    {
        public string id;
        public string Id
        {
            get { return id; }
            set { id = value; OnPropertyChanged(Id); }
        }
        public string rank; 
        public string Rank
        {
            get { return rank; } 
            set { rank = value; OnPropertyChanged(Rank); } 
        }
        public string symbol { get; set; }
        public string Symbol
        {
            get { return symbol; }
            set { symbol = value; OnPropertyChanged(Symbol); }
        }
        public string name { get; set; }
        public string Name
        {
            get { return name; }
            set { name = value; OnPropertyChanged(Name); }
        }
        public string supply { get; set; }
        public string Supply
        {
            get { return supply; }
            set { supply = value; OnPropertyChanged(Supply); }
        }
        public string maxSupply { get; set; }
        public string marketCapUsd { get; set; }
        public string MarketCap
        {
            get { return marketCapUsd; }
            set { marketCapUsd = value; OnPropertyChanged(MarketCap); }
        }
        public string volumeUsd24Hr { get; set; }
        public string Volume
        {
            get { return volumeUsd24Hr; }
            set { volumeUsd24Hr = value; OnPropertyChanged(Volume); }
        }
        public string priceUsd;
        public string Price
        {
            get { return priceUsd; }
            set { priceUsd = value; OnPropertyChanged(Price); }
        }
        public string changePercent24Hr { get; set; }
        public string PriceChange
        {
            get { return changePercent24Hr; }
            set { changePercent24Hr = value; OnPropertyChanged(PriceChange); }
        }
        public string vwap24Hr { get; set; }
        public string explorer { get; set; }
        public string Link
        {
            get { return explorer; }
            set { explorer = value; OnPropertyChanged(Link); }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string p)
        {
            PropertyChangedEventHandler pc = PropertyChanged;
            if (pc != null)
            {
                pc(this, new PropertyChangedEventArgs(p));
            }
        }
    }
}
