﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace WpfApp2.Models
{
    public class ThemeManager
    {
        public void SwitchTheme(Theme theme)
        {
            if (theme == Theme.Light)
            {
                // Apply light theme
                Application.Current.Resources["AppBackground"] = "LightGray";
                Application.Current.Resources["AppForeground"] = "Black";
            }
            else if (theme == Theme.Dark)
            {
                // Apply dark theme
                Application.Current.Resources["AppBackground"] = "DarkGray";
                Application.Current.Resources["AppForeground"] = "White";
            }
        }
    }

    public enum Theme
    {
        Light,
        Dark
    }
}
