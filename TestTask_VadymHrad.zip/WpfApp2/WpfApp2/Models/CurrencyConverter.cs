﻿using System;

namespace WpfApp2.Models
{
    public class CurrencyConverter
    {
        public decimal Convert(decimal amount, Currency fromCurrency, Currency toCurrency)
        {
            decimal fromPrice = decimal.Parse(fromCurrency.Price);
            decimal toPrice = decimal.Parse(toCurrency.Price);
            if (fromPrice != 0)
            {
                decimal convertedAmount = (amount / fromPrice) * toPrice;
                return convertedAmount;
            }
            return 0;
        }
    }
}