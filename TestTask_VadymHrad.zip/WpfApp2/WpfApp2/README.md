## Description

The project is a test task for a job application. It is a webpage that contains tree view of employees and an admin panel to manage the database of employees

## Technologies

- .NET Framework
- WPF
- Microsoft Visual Studio
- CoinCap API

## Additional Packages

To start up the project you need to install following packages with NuGet Package Manager or Package Manager Console:
- Newtonsoft.Json
- MvvmLightLibs

## How To Use

There is a commented function in MainWindow.xaml.cs which parses top 10 cryptocurrencies int a json file which should be then edited to make deserialization in a proper way
There are 3 windows MainWindow displaying top 10 cryptocurrencies and allows to search them by name
By pressing display button you move to Details Window which displays deatails about chosen cryptocurrency
Also in MainWindow is a button transfering to Converter which is fully implemented