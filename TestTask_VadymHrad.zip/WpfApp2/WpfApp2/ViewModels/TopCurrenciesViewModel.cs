﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using WpfApp2.Models;
using Newtonsoft.Json;
using System.IO;
using System.Web;
using System.Net;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Windows.Data;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using WpfApp2.Views;
using GalaSoft.MvvmLight.Command;

namespace WpfApp2.ViewModels
{
    public class TopCurrenciesViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public ICommand OpenCurrencyDetailsCommand { get; }
        public ICommand OpenCurrencyConverterCommand { get; }

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public TopCurrenciesViewModel()
        {
            OpenCurrencyDetailsCommand = new RelayCommand<Currency>(OpenCurrencyDetails);
            OpenCurrencyConverterCommand = new RelayCommand(OpenCurrencyConverter);
        }

        private void OpenCurrencyDetails(Currency selectedCurrency)
        {
            CurrencyDetailsViewModel detailsViewModel = new CurrencyDetailsViewModel(selectedCurrency);
            Details detailsView = new Details();
            detailsView.DataContext = detailsViewModel;
            detailsView.Show();
        }
        private void OpenCurrencyConverter()
        {
            CurrencyConverterViewModel converterViewModel = new CurrencyConverterViewModel();
            Views.CurrencyConverter converterView = new Views.CurrencyConverter();
            converterView.DataContext = converterViewModel;
            converterView.Show();
        }
        private Currency currency;
        public Currency Currency
        {
            get { return currency; }
            set { currency = value; OnPropertyChanged(); }
        }

        private ObservableCollection<Currency> currencies;
        public ObservableCollection<Currency> Currencies
        {
            get { return currencies; }
            set { currencies = value; OnPropertyChanged(); }
        }
    }
}
