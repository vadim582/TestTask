﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using WpfApp2.Models;
using WpfApp2.Views;

namespace WpfApp2.ViewModels
{
    public class CurrencyDetailsViewModel : INotifyPropertyChanged
    {
        private Currency selectedCurrency;
        //private Views.CurrencyConverter currencyConverter; public ThemeManager ThemeManager { get; }
      
        public Currency SelectedCurrency
        {
            get { return selectedCurrency; }
            set
            {
                selectedCurrency = value;
                OnPropertyChanged();
            }
        }
        public string id;
        public string Id
        {
            get { return id; }
            set
            {
                id = value;
                OnPropertyChanged();
            }
        }
        public string rank;
        public string Rank
        {
            get { return rank; }
            set
            {
                rank = value;
                OnPropertyChanged();
            }
        }
        public string symbol;
        public string Symbol
        {
            get { return symbol; }
            set
            {
                symbol = value;
                OnPropertyChanged();
            }
        }
        public string name { get; set; }
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                OnPropertyChanged();
            }
        }
        public string supply;
        public string Supply
        {
            get { return supply; }
            set
            {
                supply = value;
                OnPropertyChanged();
            }
        }
        public string maxSupply;
        public string marketCapUsd;
        public string MarketCap
        {
            get { return marketCapUsd; }
            set
            {
                marketCapUsd = value;
                OnPropertyChanged();
            }
        }
        public string volumeUsd24Hr { get; set; }
        public string Volume
        {
            get { return volumeUsd24Hr; }
            set
            {
                volumeUsd24Hr = value;
                OnPropertyChanged();
            }
        }
        public string priceUsd;
        public string Price
        {
            get { return priceUsd; }
            set
            {
                priceUsd = value;
                OnPropertyChanged();
            }
        }
        public string changePercent24Hr { get; set; }
        public string PriceChange
        {
            get { return changePercent24Hr; }
            set
            {
                changePercent24Hr = value;
                OnPropertyChanged();
            }
        }
        public string vwap24Hr { get; set; }
        public string explorer { get; set; }
        public string Link
        {
            get { return explorer; }
            set
            {
                explorer = value;
                OnPropertyChanged();
            }
        }
        private void LoadCurrencyDetails()
        {
            Id = SelectedCurrency.Id;
            Rank = SelectedCurrency.Rank;
            Symbol = SelectedCurrency.Symbol;
            Name = SelectedCurrency.Name;
            Supply = SelectedCurrency.Supply;
            MarketCap = SelectedCurrency.MarketCap;
            Volume = SelectedCurrency.Volume;
            Price = SelectedCurrency.Price;
            PriceChange = SelectedCurrency.PriceChange;
            Link = SelectedCurrency.Link;
        }
        private RelayCommand openCurrencyPageCommand;
        public RelayCommand OpenCurrencyPageCommand
        {
            get
            {
                if (openCurrencyPageCommand == null)
                {
                    openCurrencyPageCommand = new RelayCommand(OpenCurrencyPageOnMarket);
                }
                return openCurrencyPageCommand;
            }
        }
        public ICommand OpenCurrencyDetailsCommand { get; }

        private void OpenCurrencyPageOnMarket()
        {
            string link = selectedCurrency.Link;
            var ps = new ProcessStartInfo(link)
            {
                UseShellExecute = true,
                Verb = "open"
            };
            Process.Start(ps);
        }
        public ICommand SwitchThemeCommand { get; }

        public ThemeManager ThemeManager { get; }
        private Theme selectedTheme;
        public Theme SelectedTheme
        {
            get { return selectedTheme; }
            set { selectedTheme = value; OnPropertyChanged(); }
        }
        public CurrencyDetailsViewModel(Currency currency)
        {
            //ThemeManager = new ThemeManager();
            SwitchThemeCommand = new RelayCommand(SwitchTheme);
            OpenCurrencyDetailsCommand = new RelayCommand(OpenCurrencyDetails);
            SelectedCurrency = currency;
            Id = currency.Id;
            Rank = currency.Rank;
            Symbol = currency.Symbol;
            Name = currency.Name;
            Supply = currency.Supply;
            MarketCap = currency.MarketCap;
            Volume = currency.Volume;
            Price = currency.Price;
            PriceChange = currency.PriceChange;
            Link = currency.Link;
        }
        private void SwitchTheme()
        {
            if (SelectedTheme == Theme.Light)
            {
                ThemeManager.SwitchTheme(Theme.Light);
            }
            else if (SelectedTheme == Theme.Dark)
            {
                ThemeManager.SwitchTheme(Theme.Dark);
            }
        }
        private void OpenCurrencyDetails()
        {
            Details detailsWindow = new Details();
            CurrencyDetailsViewModel detailsViewModel = new CurrencyDetailsViewModel(SelectedCurrency);
            detailsWindow.DataContext = detailsViewModel;
            detailsWindow.Show();
        }
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
