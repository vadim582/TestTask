﻿using Newtonsoft.Json;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using WpfApp2.Models;

namespace WpfApp2.ViewModels
{
    public class CurrencyConverterViewModel : INotifyPropertyChanged
    {
        public ThemeManager ThemeManager { get; }
        public ObservableCollection<Currency> Currencies { get; set; }
        public ICommand ConvertCommand { get; }
        private void Convert()
        {
            if (FromCurrency != null && ToCurrency != null)
            {
                if (decimal.TryParse(FromCurrency.Price, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal fromRate) &&
                    decimal.TryParse(ToCurrency.Price, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal toRate) &&
                    decimal.TryParse(AmountToConvert.ToString(), out decimal amount))
                {
                    decimal convertedAmount = amount * (fromRate / toRate);
                    ConvertedAmount = convertedAmount;
                }
                else
                {
                    // Handle the case when parsing fails (e.g., invalid decimal values)
                    // Set ConvertedAmount to a default value or show an error message
                }
            }
        }
        private decimal amountToConvert;
        public decimal AmountToConvert
        {
            get { return amountToConvert; }
            set { amountToConvert = value; OnPropertyChanged(); }
        }

        private Currency fromCurrency;
        public Currency FromCurrency
        {
            get { return fromCurrency; }
            set { fromCurrency = value; OnPropertyChanged(); }
        }

        private Currency toCurrency;
        public Currency ToCurrency
        {
            get { return toCurrency; }
            set { toCurrency = value; OnPropertyChanged(); }
        }

        private decimal convertedAmount;
        public decimal ConvertedAmount
        {
            get { return convertedAmount; }
            set { convertedAmount = value; OnPropertyChanged(); }
        }

        private CurrencyConverter currencyConverter;
        public ICommand SwitchThemeCommand { get; }

        public CurrencyConverterViewModel()
        {
            ThemeManager = new ThemeManager();
            ConvertCommand = new RelayCommand(Convert);
            currencyConverter = new CurrencyConverter();
            string json = File.ReadAllText("ApiData.json");
            Currencies = JsonConvert.DeserializeObject<ObservableCollection<Currency>>(json);
        }

        public void ConvertCurrency()
        {
            ConvertedAmount = currencyConverter.Convert(AmountToConvert, FromCurrency, ToCurrency);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}